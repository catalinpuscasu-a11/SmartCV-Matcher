\# SmartCV Matcher



SmartCV Matcher este o aplicație dezvoltată în Python, care calculează scorul de potrivire dintre CV-uri și descrieri de job folosind tehnici NLP (TF-IDF \& Cosine Similarity). Proiectul generează automat rapoarte în format Excel, clasând candidații în funcție de relevanța pentru fiecare rol.



---



\##  Funcționalități

\- Procesarea textelor din CV și descrieri job

\- Calcularea scorului de potrivire între candidați și roluri

\- Generare rapoarte Excel

\- Interfață grafică (GUI) pentru rulare fără consolă

\- Structură organizată pe foldere (data, src, results)



---



\##  Tehnologii folosite



| Componentă | Tehnologie |

|-----------|------------|

| Limbaj | Python 3 |

| Procesare NLP | scikit-learn (TF-IDF, Cosine Similarity) |

| Prelucrare date | pandas |

| Output | Excel / openpyxl |

| GUI | Tkinter |



---



\##  Structura proiectului





