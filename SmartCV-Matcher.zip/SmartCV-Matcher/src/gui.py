import tkinter as tk
from tkinter import messagebox
from matcher import CVMatcher
from utils import get_excel_path


def run_matching():
    try:
        import os

        # creăm folderul results dacă nu există
        if not os.path.exists("results"):
            os.makedirs("results")

        matcher = CVMatcher()
        excel_path = get_excel_path()
        matcher.load_data(excel_path)
        matcher.fit()

        matcher.match().to_excel("results/matching_results_all.xlsx", index=False)
        matcher.best_match_for_each_cv().to_excel("results/matching_results_best.xlsx", index=False)

        messagebox.showinfo("Succes", "Rapoartele au fost generate în folderul 'results'!")
    except Exception as e:
        messagebox.showerror("Eroare", str(e))

def main():
    window = tk.Tk()
    window.title("SmartCV Matcher")
    window.geometry("400x200")

    title_label = tk.Label(window, text="SmartCV Matcher", font=("Arial", 18, "bold"))
    title_label.pack(pady=10)

    desc_label = tk.Label(
        window,
        text="Apasă butonul pentru a calcula potrivirea CV–Job\nși a genera rapoartele în Excel.",
        justify="center"
    )
    desc_label.pack(pady=5)

    run_button = tk.Button(window, text="Rulează Matching", command=run_matching, width=25, height=2)
    run_button.pack(pady=15)

    window.mainloop()


if __name__ == "__main__":
    main()
