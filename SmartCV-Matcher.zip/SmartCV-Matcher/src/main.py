from matcher import CVMatcher
from utils import get_excel_path


def main():
    excel_path = get_excel_path()

    matcher = CVMatcher()
    matcher.load_data(excel_path)
    matcher.fit()

    # toate potrivirile CV–Job
    all_matches = matcher.match()
    all_matches.to_excel("matching_results_all.xlsx", index=False)

    # cel mai bun job pentru fiecare CV
    best_matches = matcher.best_match_for_each_cv()
    best_matches.to_excel("matching_results_best.xlsx", index=False)

    print("✅ Gata!")
    print("Rezultatele au fost salvate în:")
    print(" - matching_results_all.xlsx")
    print(" - matching_results_best.xlsx\n")

    print("Top potriviri (cel mai bun job pentru fiecare CV):")
    print(best_matches)


if __name__ == "__main__":
    main()
