from typing import Optional
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class CVMatcher:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(stop_words="english")
        self.cvs: Optional[pd.DataFrame] = None
        self.jobs: Optional[pd.DataFrame] = None
        self._matrix = None

    def load_data(self, excel_path: str, cvs_sheet: str = "cvs", jobs_sheet: str = "jobs") -> None:
        self.cvs = pd.read_excel(excel_path, sheet_name=cvs_sheet)
        self.jobs = pd.read_excel(excel_path, sheet_name=jobs_sheet)

    def fit(self) -> None:
        all_texts = list(self.cvs["cv_text"].astype(str)) + list(self.jobs["descriere_job"].astype(str))
        self._matrix = self.vectorizer.fit_transform(all_texts)

    def match(self) -> pd.DataFrame:
        n_cvs = len(self.cvs)
        n_jobs = len(self.jobs)
        cv_vectors = self._matrix[:n_cvs]
        job_vectors = self._matrix[n_cvs:n_cvs + n_jobs]
        similarity_matrix = cosine_similarity(cv_vectors, job_vectors)

        results = []
        for i, cv_row in self.cvs.iterrows():
            for j, job_row in self.jobs.iterrows():
                score = similarity_matrix[i, j]
                results.append({
                    "cv_id": cv_row["id"],
                    "nume": cv_row.get("nume", ""),
                    "job_id": job_row["id"],
                    "titlu_job": job_row.get("titlu_job", ""),
                    "score_potrivire": round(float(score) * 100, 2)
                })

        return pd.DataFrame(results).sort_values("score_potrivire", ascending=False)

    def best_match_for_each_cv(self) -> pd.DataFrame:
        df_all = self.match()
        return (
            df_all.sort_values("score_potrivire", ascending=False)
                  .groupby("cv_id", as_index=False)
                  .head(1)
        )
