import os

def get_excel_path() -> str:
    excel_path = os.path.join("data", "SmartCV-Matcher.xlsx")
    if not os.path.exists(excel_path):
        raise FileNotFoundError("Nu există SmartCV-Matcher.xlsx în folderul /data")
    return excel_path
